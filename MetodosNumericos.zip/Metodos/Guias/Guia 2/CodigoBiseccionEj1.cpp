#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

/////////////////////
///DEFINIR TOLERANCIA
/////////////////////
#define ERROR pow(10, -5)

/////////////////////
///DEFINIR INTERVALO
/////////////////////
#define A 100.0
#define B 1000.0

double function(double);

///////////////////
///DEFINIR FUNCION
//////////////////
double function(double m) {
	double g = 9.81;
	double c = 14.00;
	double v = 35.0;
	double t = 7.0;
	return g*m/c*(1-exp(-c / m*t)) ;
}

int main() {
	
	// intervalo que abarca la raiz
	double a = A;
	double b = B;
	
	double cn, cv;
	double eAproximado, ePorcentual = 0;
	double tolerancia = ERROR;
	int iteraciones = 0;
	
	cout << "BISECCION" << endl;
	
	if (function(a) * function(b) < 0) { //Si hay una raiz entre a y b
		do { 
			if (iteraciones == 0) {
				cn = (a + b) / 2;
				cv = a;
				eAproximado = fabs(cn - cv);
				ePorcentual = fabs(eAproximado / cn) * 100;
			} else {
				if (function(a) * function(cn) < 0) { //Si hay una raiz entre a y cn, se mueve cn a b
					b = cn;
					cv = cn; //Se actualiza el c
					cn = (a + b) / 2;
					eAproximado = fabs(cn - cv);
					ePorcentual = (eAproximado / cn) * 100;
				} else if (function(b) * function(cn) < 0) { //Si hay una raiz entre by cn, se mueve cn a a
					a = cn;
					cv = cn; //Se actualiaz el c
					cn = (a + b) / 2;
					eAproximado = fabs(cn - cv);
					ePorcentual = (eAproximado / cn) * 100;
				} else {
					break;
				}
			}
			iteraciones++;
		} while (eAproximado > tolerancia);
		cout  << fixed << setprecision(20)<< "Raiz: "  << fixed << setprecision(20)<< cn << "\nError aproximado: " << eAproximado << "\nError porcentual: " << ePorcentual
			<< "\nIteraciones: " << iteraciones << endl;
		cout << "la funcion en dicho punto es: " << (int) function(cn) << endl;
	} else {
		cout << "La funcion no tiene raices o  la misma no se encuentra en el intervalo elegido" << endl;
	}
	
	return 0;
}
