void gaussSeidel(double matrix[MAXROWS][MAXCOLUMS], double b[MAXROWS], int rows, int columns) {
	// Declaraci�n de vectores para las soluciones actuales (newX) y anteriores (oldX)
	double newX[MAXCOLUMS] = {0};
	double oldX[MAXCOLUMS] = {0};
	double e = 0; // Variable para el error
	int iterations = 0; // Contador de iteraciones
	double sum = 0;
	
	double tolerance = ERROR; // Tolerancia para la convergencia
	
	// Verificar si la matriz es diagonalmente dominante (importante para la convergencia)
	diagonallyDominant(matrix, rows, columns);
	
	// Ciclo principal del m�todo Gauss-Seidel
	do {
		e = 0; // Inicializar el error en cada iteraci�n
		iterations++; // Incrementar el contador de iteraciones
		for (int indexA = 0; indexA < rows; indexA++) {
			
			if (indexA == 0) {
				sum = 0;
				// Este bucle for calcula la suma de los productos de los elementos de la matriz
				// en la fila indexA (excepto el elemento de la diagonal) por los valores de newX
				// que ya se han calculado en la iteraci�n actual.
				for (int indexB = 1; indexB < rows; ++indexB) {
					sum = sum + matrix[indexA][indexB] * oldX[indexB];
				}
				// Calcular el nuevo valor de la variable x[indexA] utilizando la f�rmula de Gauss-Seidel.
				newX[indexA] = (b[indexA] - sum) / matrix[indexA][indexA];
				
			} else {
				sum = 0;
				// En este bucle for, se calcula la suma de los productos de los elementos de la matriz
				// en la fila indexA que est�n a la izquierda de la diagonal (elementos con �ndices menores)
				// por los valores actualizados de newX correspondientes.
				for (int indexB = 0; indexB < indexA; ++indexB) {
					sum = sum + matrix[indexA][indexB] * newX[indexB];
				}
				
				// En este bucle for, se calcula la suma de los productos de los elementos de la matriz
				// en la fila indexA que est�n a la derecha de la diagonal (elementos con �ndices mayores)
				// por los valores antiguos de oldX correspondientes.
				for (int indexB = indexA + 1; indexB < rows; ++indexB) {
					sum = sum + matrix[indexA][indexB] * oldX[indexB];
				}
				
				// Calcular el nuevo valor de la variable x[indexA] utilizando la f�rmula de Gauss-Seidel.
				newX[indexA] = (b[indexA] - sum) / matrix[indexA][indexA];
			}
		}
		
		// Calcular el error en esta iteraci�n
		for (int index = 0; index < rows; ++index) {
			e = e + pow(newX[index] - oldX[index], 2);
		}
		e = sqrt(e);
		
		// Actualizar el vector de soluciones anteriores (oldX) con los nuevos valores (newX).
		for (int index = 0; index < rows; ++index) {
			oldX[index] = newX[index];
		}
		
	} while (tolerance < e && iterations <  MAXITERATIONS);
	
	// Comprobar si se alcanz� el n�mero m�ximo de iteraciones
	if (iterations ==  MAXITERATIONS)
		cout << "Numero de iteraciones maximas alcanzadas" << endl;
	
	// Imprimir la soluci�n encontrada y el error
	cout << "Conjunto solucion:" << endl;
	for (int indexA = 0; indexA < rows; ++indexA) {
		cout << "x" << indexA << "=" << newX[indexA] << endl;
	}
	cout << "Error:" << e << "\n" << "Iteraciones:" << iterations << endl;
}
